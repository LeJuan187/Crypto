// Copyright (c) 2011-2016 The Cryptonote developers
// Distributed under the MIT/X11 software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#pragma once

#if defined(_MSC_VER)
#define POD_CLASS struct
#else
#define POD_CLASS class
#endif
